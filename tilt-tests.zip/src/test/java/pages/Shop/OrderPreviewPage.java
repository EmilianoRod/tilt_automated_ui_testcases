package pages.Shop;

   import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.BasePage;
import pages.Shop.Stripe.StripeCheckoutPage;





    public class OrderPreviewPage extends BasePage {

        // Constructor
        public OrderPreviewPage(WebDriver driver) {
            super(driver);
        }

        // Locators
        private final By couponCheckbox = By.xpath("//label[contains(., 'I have a coupon code')]");
        private final By previousButton = By.xpath("//button[contains(., 'Previous')]");
        private final By payWithStripeButton = By.xpath("//button[@type='submit']//*[name()='svg']");



        private final By pageHeader = By.xpath("//h1[normalize-space()='Purchase Information']"); // Validación de carga de página

        // ======== Actions ========

        /**
         * Verifica si la página Order Preview está cargada.
         */
        public boolean isLoaded() {
            return isVisible(pageHeader);
        }

        /**
         * Marca el checkbox "I have a coupon code".
         */
        public void checkCouponCheckbox() {
            wait.waitForElementClickable(couponCheckbox).click();
        }

        /**
         * Hace clic en el botón "Previous" para volver al paso anterior.
         */
        public void clickPrevious() {
            wait.waitForElementClickable(previousButton).click();
        }

        /**
         * Hace clic en el botón "Pay With Stripe" y navega a la página de Stripe.
         *
         * @return StripeCheckoutPage
         */
        public StripeCheckoutPage clickPayWithStripe() {
            wait.waitForElementClickable(payWithStripeButton).click();
            return new StripeCheckoutPage(driver);
        }

}
