package pages.Shop.Stripe;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages.BasePage;

import java.util.List;

public class StripeCheckoutPage extends BasePage{



    private final StripeApiHelper stripeApiHelper;

    public StripeCheckoutPage(WebDriver driver) {
        super(driver);
        // Initialize Stripe helper with your TEST secret key
        this.stripeApiHelper = new StripeApiHelper("sk_test_123456789");
    }

    /**
     * Confirm payment using Stripe API.
     *
     * @param paymentIntentId the PaymentIntent ID created for this order
     * @return true if payment succeeded, false otherwise
     */
    public boolean confirmPayment(String paymentIntentId) {
        System.out.println("💳 Confirming payment via Stripe API for PaymentIntent: " + paymentIntentId);
        return stripeApiHelper.confirmTestPayment(paymentIntentId);
    }

    /**
     * Retrieve the latest PaymentIntent ID for the given email.
     *
     * @param email the customer's email
     * @return the latest PaymentIntent ID or null if none found
     */
    public String getLatestPaymentIntentId(String email) {
        return stripeApiHelper.getLatestPaymentIntentIdForEmail(email);
    }

    /**
     * Verify if a payment succeeded for a given PaymentIntent.
     *
     * @param paymentIntentId the PaymentIntent ID
     * @return true if succeeded, false otherwise
     */
    public boolean isPaymentSuccessful(String paymentIntentId) {
        return stripeApiHelper.isPaymentSuccessful(paymentIntentId);
    }


}
