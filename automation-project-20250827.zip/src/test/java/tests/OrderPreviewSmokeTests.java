package tests;

import Utils.Config;
import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.Shop.AssessmentEntryPage;
import pages.Shop.OrderPreviewPage;
import pages.Shop.PurchaseRecipientSelectionPage;
import pages.menuPages.DashboardPage;
import pages.menuPages.ShopPage;

import java.util.UUID;

public class OrderPreviewSmokeTests extends BaseTest{


    @Test(groups = {"shop","preview","smoke"})
    public void testOrderPreviewShowsCorrectItemAndAllowsContinue() {
        // 1) Login
        LoginPage login = new LoginPage(driver);
        login.navigateTo();
        DashboardPage dashboard = login.login(Config.getAdminEmail(), Config.getAdminPassword());
        Assert.assertTrue(dashboard.isLoaded(), "Dashboard did not load after login");

        // 2) Start purchase (True Tilt example — adjust if the button method differs)
        ShopPage shop = dashboard.goToShop();
        PurchaseRecipientSelectionPage select = shop.clickBuyNowForTrueTilt();
        select.selectClientOrIndividual();   // adjust to your exact label if needed
        select.clickNext();

        // 3) Manual entry for a single recipient
        AssessmentEntryPage entry = new AssessmentEntryPage(driver);
        entry.selectManualEntry();
        entry.enterNumberOfIndividuals("1");

        String email = "qa+" + UUID.randomUUID().toString().substring(0,8) + "@example.com";
        entry.fillUserDetailsAtIndex(0, "Emi", "Rod", email);

        // 4) Verify Order Preview
        OrderPreviewPage preview = entry.clickProceedToPayment().waitUntilLoaded();

        boolean byText = preview.hasProductNamed("True Tilt Personality Profile");
        boolean byImg  = preview.hasProductImageMatching("true tilt personality profile", "shop-ttp", "true tilt");

        Assert.assertTrue(byText || byImg,
                "Expected 'True Tilt Personality Profile' item (text or image) in Order Preview.");
        Assert.assertTrue(preview.isProceedEnabled(), "Proceed/Pay button should be enabled.");
    }


    @Test(groups = {"shop","preview"})
    public void testCouponStatePersistsAcrossPreviousAndNext() {
        // Login
        LoginPage login = new LoginPage(driver);
        login.navigateTo();
        DashboardPage dashboard = login.login(Config.getAdminEmail(), Config.getAdminPassword());
        Assert.assertTrue(dashboard.isLoaded(), "Dashboard did not load after login");

        // Start purchase
        ShopPage shop = dashboard.goToShop();
        PurchaseRecipientSelectionPage select = shop.clickBuyNowForTrueTilt();
        select.selectClientOrIndividual();
        select.clickNext();

        // Manual entry for a single recipient
        AssessmentEntryPage entry = new AssessmentEntryPage(driver);
        entry.selectManualEntry();
        entry.enterNumberOfIndividuals("1");
        String email = "qa+" + UUID.randomUUID().toString().substring(0,8) + "@example.com";
        entry.fillUserDetailsAtIndex(0, "Emi", "Rod", email);


        // Preview loads
        OrderPreviewPage preview = entry.clickProceedToPayment().waitUntilLoaded();

        // --- Case A: set to CHECKED, go back & forward, expect CHECKED ---
        preview.setCouponChecked(true);
        Assert.assertTrue(preview.isCouponChecked(), "Coupon should be checked after setting it.");

        preview.clickPrevious();          // back to entry step
        entry.clickProceedToPayment();               // forward to preview again
        preview.waitUntilLoaded();

        Assert.assertTrue(preview.isCouponChecked(),
                "Coupon checkbox state should persist as CHECKED after navigating Previous → Next.");

        // --- Case B: set to UNCHECKED, go back & forward, expect UNCHECKED ---
        preview.setCouponChecked(false);
        Assert.assertFalse(preview.isCouponChecked(), "Coupon should be unchecked after setting it.");

        preview.clickPrevious();
        entry.clickProceedToPayment();
        preview.waitUntilLoaded();

        Assert.assertFalse(preview.isCouponChecked(),
                "Coupon checkbox state should persist as UNCHECKED after navigating Previous → Next.");

        // Sanity: proceed CTA still enabled on a valid preview
        Assert.assertTrue(preview.isProceedEnabled(), "Proceed/Pay button should be enabled.");
    }


}
