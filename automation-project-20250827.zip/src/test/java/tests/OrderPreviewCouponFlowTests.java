package tests;

import base.BaseTest;
import Utils.Config;
import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.Shop.AssessmentEntryPage;
import pages.Shop.OrderPreviewPage;
import pages.Shop.PurchaseRecipientSelectionPage;
import pages.menuPages.DashboardPage;
import pages.menuPages.ShopPage;


import java.util.UUID;

public class OrderPreviewCouponFlowTests extends BaseTest {



    @Test(groups = {"shop","preview","coupon","smoke"})
    public void testCouponDefaultUncheckedOnFirstLoad() {
        // Login
        LoginPage login = new LoginPage(driver);
        login.navigateTo();
        DashboardPage dashboard = login.login(Config.getAdminEmail(), Config.getAdminPassword());
        Assert.assertTrue(dashboard.isLoaded(), "Dashboard did not load after login");

        // Start purchase
        ShopPage shop = dashboard.goToShop();
        PurchaseRecipientSelectionPage select = shop.clickBuyNowForTrueTilt();
        select.selectClientOrIndividual();
        select.clickNext();

        // Manual entry for a single recipient
        AssessmentEntryPage entry = new AssessmentEntryPage(driver);
        entry.selectManualEntry();
        entry.enterNumberOfIndividuals("1");
        String email = "qa+" + UUID.randomUUID().toString().substring(0,8) + "@example.com";
        entry.fillUserDetailsAtIndex(0, "Emi", "Rod", email);

        // Preview
        OrderPreviewPage preview = entry.clickProceedToPayment().waitUntilLoaded();

        // Default should be OFF on first load
        Assert.assertFalse(preview.isCouponChecked(),
                "Coupon should be unchecked by default on first load of Order Preview.");

        // Sanity
        Assert.assertTrue(preview.isProceedEnabled(), "Proceed/Pay button should be enabled.");
    }

    @Test(groups = {"shop","preview","coupon"})
    public void testCouponPersistsWhenChecked_FullFlow() {
        // Login
        LoginPage login = new LoginPage(driver);
        login.navigateTo();
        DashboardPage dashboard = login.login(Config.getAdminEmail(), Config.getAdminPassword());
        Assert.assertTrue(dashboard.isLoaded(), "Dashboard did not load after login");

        // Start purchase
        ShopPage shop = dashboard.goToShop();
        PurchaseRecipientSelectionPage select = shop.clickBuyNowForTrueTilt();
        select.selectClientOrIndividual();
        select.clickNext();

        // Manual entry for a single recipient
        AssessmentEntryPage entry = new AssessmentEntryPage(driver);
        entry.selectManualEntry();
        entry.enterNumberOfIndividuals("1");
        String email = "qa+" + UUID.randomUUID().toString().substring(0,8) + "@example.com";
        entry.fillUserDetailsAtIndex(0, "Emi", "Rod", email);

        // Preview
        OrderPreviewPage preview = entry.clickProceedToPayment().waitUntilLoaded();

        // Set CHECKED → back → forward → expect CHECKED
        preview.setCouponChecked(true);
        Assert.assertTrue(preview.isCouponChecked(), "Coupon should be checked after setting it.");

        preview.clickPrevious();                 // back to entry step
        entry.clickProceedToPayment();           // forward to preview
        preview.waitUntilLoaded();

        Assert.assertTrue(preview.isCouponChecked(),
                "Coupon should remain CHECKED after Previous → Proceed → Preview.");
    }

    @Test(groups = {"shop","preview","coupon"})
    public void testCouponPersistsWhenUnchecked_FullFlow() {
        // Login
        LoginPage login = new LoginPage(driver);
        login.navigateTo();
        DashboardPage dashboard = login.login(Config.getAdminEmail(), Config.getAdminPassword());
        Assert.assertTrue(dashboard.isLoaded(), "Dashboard did not load after login");

        // Start purchase
        ShopPage shop = dashboard.goToShop();
        PurchaseRecipientSelectionPage select = shop.clickBuyNowForTrueTilt();
        select.selectClientOrIndividual();
        select.clickNext();

        // Manual entry for a single recipient
        AssessmentEntryPage entry = new AssessmentEntryPage(driver);
        entry.selectManualEntry();
        entry.enterNumberOfIndividuals("1");
        String email = "qa+" + UUID.randomUUID().toString().substring(0,8) + "@example.com";
        entry.fillUserDetailsAtIndex(0, "Emi", "Rod", email);

        // Preview
        OrderPreviewPage preview = entry.clickProceedToPayment().waitUntilLoaded();

        // Set UNCHECKED → back → forward → expect UNCHECKED
        preview.setCouponChecked(false);
        Assert.assertFalse(preview.isCouponChecked(), "Coupon should be unchecked after setting it.");

        preview.clickPrevious();                 // back to entry step
        entry.clickProceedToPayment();           // forward to preview
        preview.waitUntilLoaded();

        Assert.assertFalse(preview.isCouponChecked(),
                "Coupon should remain UNCHECKED after Previous → Proceed → Preview.");

        // Sanity
        Assert.assertTrue(preview.isProceedEnabled(), "Proceed/Pay button should be enabled.");
    }

}
