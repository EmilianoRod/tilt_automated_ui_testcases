package pages.Shop;

   import org.openqa.selenium.*;
   import pages.BasePage;
   import pages.Shop.Stripe.StripeCheckoutPage;





    public class OrderPreviewPage extends BasePage {

        // Constructor
        public OrderPreviewPage(WebDriver driver) {
            super(driver);
        }

        // --- Locators (more tolerant & semantic) ---
        private final By header = By.xpath(
                "//*[self::h1 or self::h2][contains(normalize-space(.),'Order Preview') or contains(normalize-space(.),'Order review')]"
        );

        private final By couponLabel = By.xpath(
                "//label[contains(normalize-space(.),'I have a coupon code') or contains(normalize-space(.),'coupon')]"
        );
        // If you want to assert state:
        private final By couponInput = By.xpath(
                "//input[@type='checkbox' and (contains(@id,'coupon') or contains(@name,'coupon') or contains(@aria-label,'coupon'))]"
        );

        private final By previousButton = By.xpath(
                "//button[contains(normalize-space(.),'Previous')]"
        );

        // Click the BUTTON, not the inner SVG
        private final By payWithStripeButton = By.xpath(
                "//button[@type='submit' or contains(.,'Pay') or .//span[contains(.,'Pay')]]"
        );

        // Optional: totals (nice to have)
        private final By subtotalValue = By.xpath("//*[contains(.,'Subtotal')]/following::*[self::span or self::div][1]");
        private final By totalValue    = By.xpath("//*[contains(.,'Total')]/following::*[self::span or self::div][1]");

        // Optional overlay/spinner guard
        private final By blockingOverlay = By.xpath(
                "//*[self::div or self::span][contains(@class,'loading') or contains(@class,'spinner') or contains(@class,'overlay') or @role='progressbar']"
        );

        // ======== Actions ========

        /** Robust check that preview is visible. */
        public boolean isLoaded() {
            try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
            try { wait.waitForElementVisible(header); return true; }
            catch (Exception e) { return false; }
        }

        public OrderPreviewPage waitUntilLoaded() {
            try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
            wait.waitForElementVisible(header);
            return this;
        }

        /** Toggle coupon checkbox via label; best-effort verify input state changed. */
        public void checkCouponCheckbox() {
            try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
            WebElement label = wait.waitForElementClickable(couponLabel);
            scrollIntoViewCenter(label);
            try { label.click(); } catch (ElementClickInterceptedException e) { jsClick(label); }

            // Optional: verify underlying input toggled (if accessible)
            try {
                WebElement input = driver.findElement(couponInput);
                // Tiny polling instead of adding a new wait signature
                long end = System.currentTimeMillis() + 2000;
                while (System.currentTimeMillis() < end && !input.isSelected()) {
                    Thread.sleep(100);
                }
            } catch (Exception ignore) {}
        }

        /** Go back to previous step. */
        public void clickPrevious() {
            try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
            WebElement btn = wait.waitForElementClickable(previousButton);
            scrollIntoViewCenter(btn);
            try { btn.click(); } catch (ElementClickInterceptedException e) { jsClick(btn); }
        }

        /** Proceed to Stripe; click the actual button (not the inner SVG). */
        public StripeCheckoutPage clickPayWithStripe() {
            try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
            WebElement btn = wait.waitForElementClickable(payWithStripeButton);
            scrollIntoViewCenter(btn);
            try { btn.click(); } catch (ElementClickInterceptedException e) { jsClick(btn); }
            return new StripeCheckoutPage(driver);
        }

        // --- Optional getters for asserts ---
        public String getSubtotalText() {
            return wait.waitForElementVisible(subtotalValue).getText().trim();
        }

        public String getTotalText() {
            return wait.waitForElementVisible(totalValue).getText().trim();
        }

        // --- Small helpers (local, no BasePage changes) ---
        private void scrollIntoViewCenter(WebElement el) {
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block:'center', inline:'nearest'});", el);
        }

        private void jsClick(WebElement el) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
        }

}
