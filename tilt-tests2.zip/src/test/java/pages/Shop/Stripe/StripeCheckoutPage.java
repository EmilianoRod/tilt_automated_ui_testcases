package pages.Shop.Stripe;

import org.openqa.selenium.*;
import pages.BasePage;

import java.util.List;

public class StripeCheckoutPage extends BasePage{



    private final StripeApiHelper stripeApiHelper;

    public StripeCheckoutPage(WebDriver driver) {
        super(driver);
        // Initialize Stripe helper with your TEST secret key
        this.stripeApiHelper = new StripeApiHelper("sk_test_123456789");
    }


    // --- Primary selectors (preferred) ---
    private final By cardNumberFrame = By.cssSelector("iframe[title='Secure card number input']");
    private final By expDateFrame    = By.cssSelector("iframe[title='Secure expiration date input']");
    private final By cvcFrame        = By.cssSelector("iframe[title='Secure CVC input']");
    private final By postalFrame     = By.cssSelector("iframe[title='Secure postal code input']");

    // --- Fallbacks (some themes/locales don’t expose titles consistently) ---
    private final By anyStripeFrame  = By.cssSelector("iframe[src*='stripe'], iframe[name*='__privateStripeFrame']");

    // Inside each Stripe iframe there is a single <input> we can type into.
    private final By inputWithinFrame = By.cssSelector("input[name], input[autocomplete]");

    // Pay/Submit button (CLICK THE BUTTON, not its icon)
    private final By payButton = By.xpath(
            "//button[@type='submit' or .//span[contains(normalize-space(.),'Pay')] or contains(normalize-space(.),'Pay')]"
    );

    // Optional overlay/spinner guard on your page
    private final By blockingOverlay = By.xpath(
            "//*[self::div or self::span][contains(@class,'loading') or contains(@class,'spinner') or contains(@class,'overlay') or @role='progressbar']"
    );

    // ---------- Public API ----------

    /** At least card number iframe should be visible. */
    public StripeCheckoutPage waitUntilLoaded() {
        try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
        waitForAny(cardNumberFrame, anyStripeFrame); // tolerate theme differences
        return this;
    }

    /** Fill all fields. Works in Stripe test mode. Example: 4242 4242 4242 4242 / 12/34 / 123 / 90210 */
    public StripeCheckoutPage fillCardDetails(String number, String expMmYy, String cvc, String postal) {
        typeIntoStripeFrame(cardNumberFrame, anyStripeFrame, number);
        typeIntoStripeFrame(expDateFrame,    anyStripeFrame, expMmYy);
        typeIntoStripeFrame(cvcFrame,        anyStripeFrame, cvc);
        // Postal may be disabled by merchant config
        if (!driver.findElements(postalFrame).isEmpty() || hasAnotherStripeFrameBeyondTyped()) {
            typeIntoStripeFrame(postalFrame, anyStripeFrame, postal);
        }
        return this;
    }

    public StripeCheckoutPage submitPayment() {
        try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
        WebElement btn = wait.waitForElementClickable(payButton);
        scrollIntoViewCenter(btn);
        try { btn.click(); } catch (ElementClickInterceptedException e) { jsClick(btn); }
        return this;
    }

    /** Convenience: do it all. */
    public StripeCheckoutPage payWithTestCard(String number, String expMmYy, String cvc, String postal) {
        return waitUntilLoaded()
                .fillCardDetails(number, expMmYy, cvc, postal)
                .submitPayment();
    }

    // ---------- Optional 3‑D Secure (enable if you use 3DS test cards) ----------
    // Test 3DS card: 4000 0027 6000 3184
    private final By threeDSFrame    = By.cssSelector("iframe[src*='3ds'], iframe[title*='challenge']");
    private final By threeDSApprove  = By.xpath("//button[normalize-space()='Complete authentication' or normalize-space()='Authorize']");

    public StripeCheckoutPage complete3DSIfPresent() {
        try {
            WebElement f = wait.waitForElementVisible(threeDSFrame);
            driver.switchTo().frame(f);
            WebElement approve = wait.waitForElementClickable(threeDSApprove);
            approve.click();
        } catch (Exception ignored) {
            // no 3DS challenge shown
        } finally {
            driver.switchTo().defaultContent();
        }
        return this;
    }

    // ---------- Helpers ----------

    private void typeIntoStripeFrame(By primary, By fallback, String text) {
        WebElement frame = getFirstVisible(primary, fallback);
        driver.switchTo().frame(frame);
        try {
            WebElement input = wait.waitForElementVisible(inputWithinFrame);
            // Select‑all then type (mask-friendly)
            input.sendKeys(Keys.chord(Keys.CONTROL, "a"));
            input.sendKeys(Keys.DELETE);
            input.sendKeys(text);
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    private WebElement getFirstVisible(By primary, By fallback) {
        // Try primary for ~2s, then fallback to "any Stripe frame"
        long deadline = System.currentTimeMillis() + 2000;
        while (System.currentTimeMillis() < deadline) {
            if (!driver.findElements(primary).isEmpty()) {
                return wait.waitForElementVisible(primary);
            }
            sleep(100);
        }
        return wait.waitForElementVisible(fallback);
    }

    private void waitForAny(By... candidates) {
        for (By b : candidates) {
            if (!driver.findElements(b).isEmpty()) {
                wait.waitForElementVisible(b);
                return;
            }
        }
        // As a last resort, block on the generic Stripe frame
        wait.waitForElementVisible(anyStripeFrame);
    }

    private boolean hasAnotherStripeFrameBeyondTyped() {
        // heuristic: if there are >=3 stripe frames, assume postal exists or another field still needs input
        return driver.findElements(anyStripeFrame).size() >= 3;
    }

    private void scrollIntoViewCenter(WebElement el) {
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block:'center', inline:'nearest'});", el);
    }

    private void jsClick(WebElement el) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }

    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

}
