package pages.Shop;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BasePage;

import java.time.Duration;
import java.util.List;

public class AssessmentEntryPage extends BasePage {

    public AssessmentEntryPage(WebDriver driver) {
        super(driver);
    }


    // --- Stable, text-anchored locators (no index-based XPaths) ---
    // Click the LABEL: it toggles the underlying (often hidden) radio input.
    private By manualEntryLabel = By.xpath(
            "//label[normalize-space()='Manual entry' or contains(normalize-space(.),'Manual')]"
    );

    // Be flexible about quantity input (ids/names can vary)
    private By quantityInput = By.xpath(
            "//input[@type='number' or @inputmode='numeric' or contains(@name,'quantity') or contains(@id,'quantity')]"
    );

    private By nextButton = By.xpath(
            "//button[.//span[normalize-space()='Next'] or normalize-space()='Next']"
    );

    // Optional overlays/spinners that may intercept clicks (safe if absent)
    private By blockingOverlay = By.xpath(
            "//*[self::div or self::span][contains(@class,'loading') or contains(@class,'spinner') or contains(@class,'overlay') or @role='progressbar']"
    );

    // --- Public API ---

    /** Page is ready when key elements are present and no obvious overlay. */
    public AssessmentEntryPage waitUntilLoaded() {
        // If the overlay is present, this waits it away; if not present, it’s a quick no-op.
        try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
        // One of these should exist on this step
        wait.waitForElementVisible(manualEntryLabel);
        return this;
    }

    /** Robustly choose “Manual entry”. Uses label (not the hidden radio), scroll, and JS fallback. */
    public AssessmentEntryPage selectManualEntry() {
        try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}

        WebElement label = wait.waitForElementVisible(manualEntryLabel);
        scrollIntoViewCenter(label);
        try {
            wait.waitForElementClickable(manualEntryLabel).click();
        } catch (ElementClickInterceptedException e) {
            jsClick(label); // if covered by a tiny overlay/animation
        }

        // Best-effort verification that the radio actually toggled ON
        try {
            WebElement radio = resolveRadioFromLabel(label);
            if (radio != null) {
                waitUntilSelected(radio);
            }
        } catch (Exception ignore) {}

        return this;
    }

    /** Set the number of individuals (defaults to 1). */
    public AssessmentEntryPage enterNumberOfIndividuals(String count) {
        String value = (count == null || count.isBlank()) ? "1" : count.trim();

        try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
        WebElement qty = wait.waitForElementClickable(quantityInput);
        scrollIntoViewCenter(qty);

        // Clear reliably and type
        qty.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        qty.sendKeys(Keys.DELETE);
        qty.sendKeys(value);
        return this;
    }

    /** Go to next step (usually Order Preview). */
    public OrderPreviewPage clickNext() {
        try { wait.waitForElementInvisible(blockingOverlay); } catch (Exception ignore) {}
        WebElement btn = wait.waitForElementClickable(nextButton);
        scrollIntoViewCenter(btn);
        try {
            btn.click();
        } catch (ElementClickInterceptedException e) {
            jsClick(btn);
        }
        return new OrderPreviewPage(driver);
    }

    // Utility used by some of your tests
    public int getTotalInputRowsRendered() {
        List<WebElement> emailFields = driver.findElements(By.xpath("//input[@placeholder='Email']"));
        return emailFields.size();
    }

    public boolean isExpectedRowCountRendered(int expected) {
        return getTotalInputRowsRendered() == expected;
    }

    // --- Private helpers (kept local to avoid changing BasePage right now) ---

    private void scrollIntoViewCenter(WebElement el) {
        ((JavascriptExecutor) driver)
                .executeScript("arguments[0].scrollIntoView({block:'center', inline:'nearest'});", el);
    }

    private void jsClick(WebElement el) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }

    /** Try to resolve the <input type='radio'> associated with the label (via @for or proximity). */
    private WebElement resolveRadioFromLabel(WebElement label) {
        try {
            String forId = label.getAttribute("for");
            if (forId != null && !forId.isBlank()) {
                return driver.findElement(By.id(forId));
            }
        } catch (NoSuchElementException ignore) {}
        try {
            return label.findElement(By.xpath("(preceding::input[@type='radio'][1] | following::input[@type='radio'][1])"));
        } catch (NoSuchElementException ignore) {}
        return null;
    }

    private void waitUntilSelected(WebElement radio) {
        // Simple polling loop so we don’t add new deps; fast and non-flaky.
        long end = System.currentTimeMillis() + 5000;
        while (System.currentTimeMillis() < end) {
            try {
                if (radio.isSelected()) return;
            } catch (StaleElementReferenceException ignored) {}
            try { Thread.sleep(100); } catch (InterruptedException ignored) {}
        }
        // If it never selected, we let the test proceed; next page actions will fail if truly not selected.
    }

}