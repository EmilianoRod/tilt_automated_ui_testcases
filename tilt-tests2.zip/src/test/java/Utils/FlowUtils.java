package Utils;

import org.openqa.selenium.WebDriver;
import pages.LoginPage;
import pages.Shop.AssessmentEntryPage;
import pages.Shop.OrderPreviewPage;
import pages.Shop.PurchaseRecipientSelectionPage;
import pages.Shop.Stripe.StripeCheckoutPage;
import pages.menuPages.DashboardPage;
import pages.menuPages.IndividualsPage;
import pages.menuPages.ShopPage;

public class FlowUtils {


    private WebDriver driver;

    public FlowUtils(WebDriver driver) {
        this.driver = driver;
    }

    public DashboardPage loginAsAdmin(String email, String password) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        return loginPage.login(email, password);
    }

    public void inviteUser(String email) {
        DashboardPage dashboardPage = new DashboardPage(driver);
        IndividualsPage individualsPage = dashboardPage.goToIndividuals();
        // If invite logic is needed, uncomment these lines:
        // individualsPage.enterInviteEmail(email);
        // individualsPage.sendInvite();
        individualsPage.waitUntilUserInviteAppears(email);
    }

    public void purchaseAssessmentForUser(String email) {
        // Go to Shop and start purchase flow
        DashboardPage dashboardPage = new DashboardPage(driver);
        ShopPage shopPage = dashboardPage.goToShop();
        PurchaseRecipientSelectionPage selectionPage = shopPage.clickBuyNowForTrueTilt();
        selectionPage.selectClientOrIndividual();
        selectionPage.clickNext();

        // Fill assessment entry form
        AssessmentEntryPage entryPage = new AssessmentEntryPage(driver);
        entryPage.selectManualEntry();
        entryPage.enterNumberOfIndividuals("1");
        entryPage.fillUserDetailsAtIndex(1, "Test", "User", email);
        entryPage.clickProceedToPayment();

        // Go to order preview and then Stripe Checkout
        OrderPreviewPage previewPage = new OrderPreviewPage(driver);
        StripeCheckoutPage stripePage = previewPage.clickPayWithStripe();

        // Use Stripe API (no UI interaction for payment)
        String paymentIntentId = stripePage.getLatestPaymentIntentId(email);
        if (paymentIntentId == null) {
            throw new RuntimeException("❌ No PaymentIntent found for email: " + email);
        }

        boolean paymentConfirmed = stripePage.confirmPayment(paymentIntentId);
        if (!paymentConfirmed) {
            throw new RuntimeException("❌ Stripe payment failed for: " + email);
        }

        System.out.println("✅ Payment successful for: " + email);
    }


}
